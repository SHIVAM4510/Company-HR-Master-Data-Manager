package com.mytech.servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

@WebServlet("/editurl")
public class EditServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public EditServlet() {
		super();
	}

	private static final String query = "UPDATE BOOKREG SET BOOKNAME=?,BOOKEDITION=?,BOOKPRICE=? WHERE ID=?";

	protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		// get printwriter
		PrintWriter pw = res.getWriter();

		// set content type
		res.setContentType("text/html");

		// get the id of record
		int id = Integer.parseInt(req.getParameter("id"));
		
		//get the edited data we want to submit in edited record
		String bookName=req.getParameter("bookName");
		String bookEdition=req.getParameter("bookEdition");
		Float bookPrice=Float.parseFloat(req.getParameter("bookPrice"));


		// load jdbc driver
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

		try {
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb", "root", "Mysql2102");
			PreparedStatement ps = conn.prepareStatement(query);

			ps.setString(1,bookName);
			ps.setString(2,bookEdition);
			ps.setFloat(3,bookPrice);
			ps.setInt(4, id);
			
			int count=ps.executeUpdate();
			if(count==1)pw.println("<h2>Record Edited Successfully!!");
			else {
				pw.println("<h2>Record is NOT Edited!!!");
			}
			
			

		} catch (SQLException se) {
			se.printStackTrace();
			pw.println("<h1>" + se.getMessage() + "</h2>");

		} catch (Exception e) {
			e.printStackTrace();
			pw.println("<h1>" + e.getMessage() + "</h2>");
		}
		pw.print("<br>");
		pw.print("<br>");
		pw.println("<a href='Home.html'>Home</a>");
		pw.print("<br>");
		pw.println("<a href='bookList'>Books List</a>");
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
